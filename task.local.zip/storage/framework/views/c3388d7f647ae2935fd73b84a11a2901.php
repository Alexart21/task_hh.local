<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta id="_csrf_token" name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    
    
    
    
    <link href="<?php echo e(asset('vue_assets/css/app.css')); ?>" rel="stylesheet">
</head>
<body>
<main>
    <?php echo e($slot); ?>

</main>

<script src="<?php echo e(asset('vue_assets/js/chunk-vendors.js')); ?>"></script>
<script src="<?php echo e(asset('vue_assets/js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Alex\OpenServer\domains\task.local\resources\views/components/layouts/main.blade.php ENDPATH**/ ?>