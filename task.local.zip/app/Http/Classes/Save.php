<?php

namespace App\Http\Classes;

interface Save
{
    public function insert();
}
