<x-layouts.main>
    <div id="app">Loading...</div>
</x-layouts.main>
